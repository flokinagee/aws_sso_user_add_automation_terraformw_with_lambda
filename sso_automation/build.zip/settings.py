import os

os.environ["name"] = "sso-user-add-automation"
os.environ["admin_arn"] = "arn:aws:sso:::permissionSet/ssoins-821083b25daa61f7/ps-dfcd094b8006531b"
os.environ["readonly_arn"] = "arn:aws:sso:::permissionSet/ssoins-821083b25daa61f7/ps-581218224c3582b9"
os.environ["region"] = "ap-southeast-1"
os.environ["intance_arn"] = "arn:aws:sso:::instance/ssoins-821083b25daa61f7"
os.environ["IdentityStoreId"] = "d-874568437653"
os.environ["email"] = "nagamanokaran@email.com"
